function [X_train, y_train, X_test, y_test] = splitdata(loan_data)
%   splitdata separates a table into it's corresponding X and Y data
%   70% of data is diverted into a training dataset
%   The remaining 30% is diverted to a test / validation dataset

    [~,col] = size(loan_data); % get number of columns / features
    X = loan_data(:, 1:col-1);
    Y = loan_data(:,col);
    % Randomly pick 70% of the data examples as the training set and the 
    % the rest as the testing set
    L = length(Y);
    R = randperm(L); % generates random permutation from 1 to L
    Sep = ceil(.70 * L); % Round 70% upwards
    i = 1;
    j = 1;
    while i < L + 1
        if i < Sep
            % First 70% of data is stored as X/Y training data
            X_train(i,:) = X(R(i), :);
            y_train(i,1) = Y(R(i));
        else
            % Latter 30% of data is stored as X/Y test data
            X_test(j,:) = X(R(i), :);
            y_test(j,1) = Y(R(i));
            j = j + 1;
        end
        i = i + 1;
    end