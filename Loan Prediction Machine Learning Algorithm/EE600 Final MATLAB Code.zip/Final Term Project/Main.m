%%  Main Program
%   This file shall serve to perform all the analysis used in our
%   exploration of the loan appoval data.
%   The loan approval data is analyzed using MNRFIT, FITGLM, and a neural
%   network method learned from the EE600 course.
clear, clc
%%  Load the test data
loan_array = loadData();
iter = 5;
accuracy = zeros(iter, 5);

%% Run built-in functions
for i = 1:iter
    [X_train, y_train, X_test, y_test]= splitdata(loan_array);
    %   Randomize the splitting of training vs. test data

    %%  Analyze using built-in MATLAB Function, mnrfit
    %   mnrfit() is provided in the add-on "Statistics and Machine Learning
    %   Toolbox"
    [Xn_train, ~, ~] = featureNormalize(X_train);
    [Xn_test, mu, sigma] = featureNormalize(X_test);
    [B_mnr, dev, stats] = mnrfit(X_train, categorical(y_train));
    %   if Y is a column vector, it must contain positive integer category
    %   numbers. We will use categorical() function to circumvent
    %   Note that B has an extra coefficient for the intercept term
    %   Thus, we must add a column of ones to the X data.
    [n, m] = size(X_train);
    [row, col] = size(X_test);
    X1n_test = [ones(row,1) Xn_test];
    X1_test = [ones(row,1) X_test];

    accuracy(i,1) = evaluateAccuracy(B_mnr, X1n_test, y_test);
    % fprintf("Accuracy using MNRFIT: %f\n", accuracy)
    %% Analyze using built-in Generalized Linear Model (GLM)
    % Note: fitglm by default chooses normal distribution
    %fprintf('Results of Generalized Linear Model(GLM)\n');
    GLM = fitglm(X_train, y_train);

    beta = GLM.Coefficients.Estimate;
    accuracy(i,2) = evaluateAccuracy(beta, X1n_test, y_test);
    % fprintf("Accuracy using FITGLM: %f\n", accuracy)

    %% Analyze using Logistic Regression, hand-written method
    % Utilize the functions written from lectures, assignment 5.
    a = .01;
    num_iters = ceil( .05 * n );
    
    %Initialize Beta:
    beta_log = zeros(m+1,1);
    
    %Run Gradient Descent
    [beta_log, l_history] = gradientAscent( [ones(n, 1) Xn_train], y_train, beta_log, a, num_iters);
    
    %Check Accuracy
    accuracy(i,5) = evaluateAccuracy(beta_log,X1n_test,y_test);
%% Run Neural Network method
alpha = .10;
% num_epochs = round(n/10,-1)

num_hidden = 5;   % number of hidden units (not including the bia unit)
num_output = 1;   % number output unit

% initialize the weights: beta1 and beta2 
beta1 = rand(num_hidden, m+1); % weights associated with links between input and hidden layers
beta2 = rand(num_output, num_hidden+1); % weights associated with links between hidden and output layers

% Run backpropagation 
[beta1, beta2, J_history] = trainNN(Xn_train, y_train, beta1, beta2, alpha);


% Plot the convergence graph
figure(1);
hold on
style = {'-b';'-g';'-r';'-c';'-k';'.b';'.g';'.r';'.c';'.k'};
plot(1:numel(J_history), J_history, char(style(i)), 'LineWidth', 2);
xlabel('Number of epochs');
ylabel('Cost J');
title('Iterations of Neural Network')
%% ========== Evaluate performance of Neural Network =============

% Instructions: The following code evaluates the performance of
%               the trained neural network model. You should 
%               complete code in evaluateAccuracyNN.m, predict_NN.m

num_test = length(y_test); % number of testing examples

% normalize input features of the testing set
Xn_test = (X_test - mu)./sigma;

accuracy(i,3) = evaluateAccuracyNN(beta1, beta2, Xn_test, y_test);

%% Try Bayes Naive Method using MATLAB Built-In Functions.
    bayes = fitcnb(X_train, y_train);
    label = predict(bayes, X_test);
    accuracy(i,4) = sum( ~xor(label, y_test) ) / length(y_test);
end
hold off
fprintf("Results of FITGLM\n")
GLM
fprintf("RESULTS:\n\n\n")
fprintf("Average accuracy using MNRFIT:%f\n", mean(accuracy(:,1)))
fprintf("Average accuracy using FITGLM:%f\n", mean(accuracy(:,2)))
fprintf("Average accuracy using Neural Network:%f\n", mean(accuracy(:,3)))
fprintf("Accuracy using Bayes Naive Method:%f\n", mean(accuracy(:,4)))
fprintf("Accuracy using Logistic Regression:%f\n", mean(accuracy(:,5)))
%%  Analysis of Results
%   Based on the results of GLM, we see that x10 has the smallest pValue 
%   compared to any other feature.
%   We can interpret x10 as the variable with greatest contribution to the
%   loan approval.
%   The raw data shows that row 10 corresponds to feature: CREDIT HISTORY.

%   Let's analyze this for a moment
LoanHistory = loan_array(:,10);
LoanApproval = loan_array(:,13);
credit = zeros(1,4);
counter = 0;
k = 1;
for L = 0:1
    for R = 0:1
        for j = 1:length(LoanHistory)
            if LoanHistory(j) == L && LoanApproval(j) == R
                counter = counter+1;
            end
        end
        credit(k) = counter;
        counter = 0;
        k = k + 1;
    end
end

figure(2);
xax = {'No Credit History','Existing Credit History'};
X = categorical(xax);
X = reordercats(X, xax);
bar(X,[credit(1:2); credit(3:4)],'stacked')
legend('Not Approved', 'Approved')
title('Credit History and Loan Approval')