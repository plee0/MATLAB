function [loan_array] = loadData()
%   loadData is a function that loads the loan approval data stored
%   in this directory.
%   Data is separated into two variables, X and Y for inputs and
%   output(s).
%   70% of data is used as the training set and the remainder are
%   stored in a test set.

 % ====================== YOUR CODE HERE ======================
    % Instructions: Import spreadsheets data, extract the first
    % # columns and store them as X. Extract the last column and 
    % store it as y. 
    filename = 'Loan_approval_data.csv';
    temp_table = readtable(filename);
    loan_array = table2array(temp_table);


% ============================================================
end